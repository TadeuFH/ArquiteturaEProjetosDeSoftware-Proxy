package padroesestruturais.compositeEx1;

import org.junit.Test;
import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.*;

public class IndividualTest {

    @Test
    public void testAddParent() {
        Individual person = new Individual("John Doe", 35);
        Individual parent = new Individual("Jane Doe", 30);
        person.addParent(parent);
        assertFalse(person.getParents().isEmpty());
    }

    @Test
    public void testRemoveParent() {
        Individual person = new Individual("John Doe", 35);
        Individual parent = new Individual("Jane Doe", 30);
        person.addParent(parent);
        person.removeParent(parent);
        assertTrue(person.getParents().isEmpty());
    }

    @Test
    public void testAddAndRemoveChild() {
        Individual parent = new Individual("John Doe", 35);
        Individual child1 = new Individual("Jane Doe", 5);
        Individual child2 = new Individual("Jack Doe", 2);

        parent.addChild(child1);
        parent.addChild(child2);

        List<Person> children = parent.getChildren();
        assertEquals(children.size(), 2);
        assertTrue(children.contains(child1));
        assertTrue(children.contains(child2));

        parent.removeChild(child1);
        children = parent.getChildren();
        assertEquals(children.size(), 1);
        assertFalse(children.contains(child1));
        assertTrue(children.contains(child2));
    }
}
