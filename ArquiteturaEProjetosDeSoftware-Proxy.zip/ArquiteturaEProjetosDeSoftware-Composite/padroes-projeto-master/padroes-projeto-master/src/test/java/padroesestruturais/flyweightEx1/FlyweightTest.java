package padroesestruturais.flyweightEx1;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;

public class FlyweightTest {
    private ResourceManager manager;

    @Before
    public void setUp() {
        manager = new ResourceManager();
    }


    @Test
    public void testFlyweight() {
        Player player1 = new Player("Player 1");
        Player player2 = new Player("Player 2");

        Weapon weapon1 = manager.getWeapon("Sword", 10);
        Weapon weapon2 = manager.getWeapon("Sword", 10);

        assertSame(weapon1, weapon2);

        weapon1.use(player1);
        assertEquals(weapon1, player1.getWeapon());
        assertEquals(null, player2.getWeapon());

        weapon2.use(player2);
        assertEquals(weapon2, player2.getWeapon());
        assertEquals( weapon1, player1.getWeapon());
    }

}
