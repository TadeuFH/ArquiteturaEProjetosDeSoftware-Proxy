package padroesestruturais.proxyEx1;
import org.junit.Assert;
import org.junit.Test;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ProxyDatabaseTest {


    @Test
    public void testSearch() {
        // Arrange
        List<String> expectedResults = Arrays.asList("resultado 1", "resultado 2", "resultado 3");
        RealDatabase realDatabase = new RealDatabase(expectedResults);
        String query = "test";
        // Act
        List<String> results = realDatabase.search(query);
        // Assert
        Assert.assertEquals(expectedResults, results);
    }


    @Test
    public void testSearchWithCachedResult() {
        // Arrange
        List<String> expectedResults = Arrays.asList("resultado 1", "resultado 2");
        Database realDatabase = new RealDatabase(expectedResults);
        Database proxyDatabase = new ProxyDatabase(realDatabase);
        String query = "test";
        proxyDatabase.search(query); // Popula o cache

        List<String> results = proxyDatabase.search(query);

        Assert.assertEquals(expectedResults, results);
    }




}


