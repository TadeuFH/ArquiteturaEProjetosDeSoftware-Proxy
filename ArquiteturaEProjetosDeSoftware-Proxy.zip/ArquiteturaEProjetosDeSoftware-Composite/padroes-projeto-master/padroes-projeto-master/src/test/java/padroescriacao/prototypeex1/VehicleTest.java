package padroescriacao.prototypeex1;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


public class VehicleTest {
        @Test
        public void testCloneHonda() {
            HondaCivic original = new HondaCivic(2020);
            HondaCivic cloned = (HondaCivic) original.clone();

            // Verifica se o objeto clonado é uma instância diferente do objeto original
            assertNotSame(original, cloned);

            // Verifica se o objeto clonado tem o mesmo make, model e year que o objeto original
            assertEquals(original.getMake(), cloned.getMake());
            assertEquals(original.getModel(), cloned.getModel());
            assertEquals(original.getYear(), cloned.getYear());
        }
}
