package padroesestruturais.adapterEx1;

public interface PlayStationController {
    String pressCross();
    String pressCircle();
    String pressSquare();
    String pressTriangle();
}