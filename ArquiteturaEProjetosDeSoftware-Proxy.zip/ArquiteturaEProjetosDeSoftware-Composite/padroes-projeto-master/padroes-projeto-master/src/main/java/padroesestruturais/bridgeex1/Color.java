package padroesestruturais.bridgeex1;

public interface Color {
    String getColor();
}

