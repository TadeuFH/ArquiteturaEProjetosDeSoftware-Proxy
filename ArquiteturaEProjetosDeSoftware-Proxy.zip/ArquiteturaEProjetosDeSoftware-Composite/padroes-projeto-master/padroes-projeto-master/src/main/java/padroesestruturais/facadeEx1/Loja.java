package padroesestruturais.facadeEx1;

import java.util.ArrayList;
import java.util.List;

public class Loja {
    private LojaFacade facade;

    public Loja(List<Produto> produtos) {
        facade = new LojaFacade(produtos);
    }
    public List<String> listarNomesProdutos() {
        List<String> nomes = new ArrayList<>();
        for (Produto produto : facade.getProdutos()) {
            nomes.add(produto.getNome());
        }
        return nomes;
    }

    public List<Produto> listarProdutos() {
        return facade.getProdutos();
    }

    public double calcularPrecoProduto(Produto produto) {
        return facade.calcularPrecoProduto(produto);
    }
}