package padroesestruturais.adapterEx1;

public interface XboxController {
    String pressA();
    String pressB();
    String pressX();
    String pressY();
}
