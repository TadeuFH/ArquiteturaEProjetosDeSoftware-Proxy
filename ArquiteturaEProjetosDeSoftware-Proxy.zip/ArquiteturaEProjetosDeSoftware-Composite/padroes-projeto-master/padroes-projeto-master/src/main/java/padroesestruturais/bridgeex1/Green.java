package padroesestruturais.bridgeex1;

public class Green implements Color {
    @Override
    public String getColor() {
        return "green";
    }
}
