package padroesestruturais.flyweightEx1;

public interface Resource {
    void use(Player player);
}
