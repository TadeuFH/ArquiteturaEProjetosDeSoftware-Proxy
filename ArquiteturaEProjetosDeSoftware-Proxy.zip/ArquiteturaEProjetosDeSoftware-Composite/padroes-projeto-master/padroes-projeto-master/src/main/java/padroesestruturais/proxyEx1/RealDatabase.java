package padroesestruturais.proxyEx1;

import java.util.Arrays;
import java.util.List;

class RealDatabase implements Database {

    private List<String> results;

    public RealDatabase(List<String> results) {
        this.results = results;
    }
    @Override
    public List<String> search(String query) {
        // Simula uma busca no banco de dados, que pode ser custosa
        return results;
    }
}
