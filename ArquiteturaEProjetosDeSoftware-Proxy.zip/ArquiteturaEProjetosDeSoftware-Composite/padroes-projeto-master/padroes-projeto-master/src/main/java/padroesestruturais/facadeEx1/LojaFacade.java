package padroesestruturais.facadeEx1;

import java.util.ArrayList;
import java.util.List;

public class LojaFacade {
    private List<Produto> produtos;

    public LojaFacade(List<Produto> produtos) {
        this.produtos = produtos;
    }

    public List<Produto> getProdutos() {
        return produtos;
    }

    public double calcularPrecoProduto(Produto produto) {
        produto.aplicarDesconto();
        return produto.getPreco();
    }
}
