package padroesestruturais.flyweightEx1;

public class Player {
    private String name;
    private Weapon weapon;

    public Player(String name) {
        this.name = name;
    }

    public void setWeapon(Weapon weapon) {
        this.weapon = weapon;
    }

    public Weapon getWeapon() {
        return weapon;
    }
}
