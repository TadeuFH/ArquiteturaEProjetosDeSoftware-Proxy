package padroesestruturais.adapterEx1;

public class PlayStationControllerImpl implements PlayStationController {
    public String pressCross() {
        return "Pressing Cross button on PlayStation controller";
    }

    public String pressCircle() {
        return "Pressing Circle button on PlayStation controller";
    }

    public String pressSquare() {
        return "Pressing Square button on PlayStation controller";
    }

    public String pressTriangle() {
        return "Pressing Triangle button on PlayStation controller";
    }
}