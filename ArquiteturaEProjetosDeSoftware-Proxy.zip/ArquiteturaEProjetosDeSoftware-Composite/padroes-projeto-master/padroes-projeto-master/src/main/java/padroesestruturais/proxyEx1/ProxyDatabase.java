package padroesestruturais.proxyEx1;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProxyDatabase implements Database {
    private Database realDatabase;
    private Map<String, List<String>> cache = new HashMap<>();

    public ProxyDatabase(Database realDatabase) {
        this.realDatabase = realDatabase;
    }

    @Override
    public List<String> search(String query) {
        if (cache.containsKey(query)) {
            return cache.get(query);
        }
        List<String> result = realDatabase.search(query);
        cache.put(query, result);
        return result;
    }
}
