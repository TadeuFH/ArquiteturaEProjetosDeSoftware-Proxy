package padroesestruturais.adapterEx1;

public class PlayStationXboxAdapter implements XboxController {
    private PlayStationController playStationController;

    public PlayStationXboxAdapter(PlayStationController playStationController) {
        this.playStationController = playStationController;
    }

    public String pressA() {
        return playStationController.pressCross();
    }

    public String pressB() {
        return playStationController.pressCircle();
    }

    public String pressX() {
        return playStationController.pressSquare();
    }

    public String pressY() {
        return playStationController.pressTriangle();
    }
}
