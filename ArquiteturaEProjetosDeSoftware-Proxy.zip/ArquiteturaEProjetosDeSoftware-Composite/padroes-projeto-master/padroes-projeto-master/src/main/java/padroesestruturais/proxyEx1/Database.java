package padroesestruturais.proxyEx1;

import java.util.List;

interface Database {
    List<String> search(String query);
}
