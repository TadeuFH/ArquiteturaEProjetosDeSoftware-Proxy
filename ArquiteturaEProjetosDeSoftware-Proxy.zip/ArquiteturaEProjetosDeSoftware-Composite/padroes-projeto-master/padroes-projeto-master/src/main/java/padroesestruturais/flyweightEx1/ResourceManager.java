package padroesestruturais.flyweightEx1;

import java.util.HashMap;
import java.util.Map;

public class ResourceManager {
    private final Map<String, Weapon> weapons = new HashMap<>();

    public Weapon getWeapon(String name, int damage) {
        String key = name + "-" + damage;
        Weapon weapon = weapons.get(key);
        if (weapon == null) {
            weapon = new Weapon(name, damage);
            weapons.put(key, weapon);
        }
        return weapon;
    }
}
