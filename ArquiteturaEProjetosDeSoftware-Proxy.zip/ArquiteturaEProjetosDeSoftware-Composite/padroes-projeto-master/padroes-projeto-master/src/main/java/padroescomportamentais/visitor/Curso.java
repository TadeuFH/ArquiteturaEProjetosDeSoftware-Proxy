package padroescomportamentais.visitor;

public class Curso {

    private String nome;

    public Curso(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
}
