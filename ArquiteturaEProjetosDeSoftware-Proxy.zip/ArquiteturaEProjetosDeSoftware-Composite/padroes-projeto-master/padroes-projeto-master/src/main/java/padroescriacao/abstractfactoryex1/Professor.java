package padroescriacao.abstractfactoryex1;


public class Professor {

    private Disciplina disciplina;
    private Nota nota;

    public Professor (FabricaAbstrata fabrica) {
        this.disciplina = fabrica.createDisciplina();
        this.nota = fabrica.createNota();
    }

    public String emitirDisciplina() {
        return this.disciplina.emitir();
    }

    public String emitirNota() {
        return this.nota.emitir();
    }
}
