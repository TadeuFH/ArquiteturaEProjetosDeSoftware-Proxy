package padroescriacao.abstractfactory;

public class HistoricoPosGraduacao implements Historico {

    public String emitir() {
        return "Histórico de Pós Graduação";
    }
}
