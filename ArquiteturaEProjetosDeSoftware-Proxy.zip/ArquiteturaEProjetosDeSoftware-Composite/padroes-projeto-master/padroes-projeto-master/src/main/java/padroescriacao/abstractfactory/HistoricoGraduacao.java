package padroescriacao.abstractfactory;

public class HistoricoGraduacao implements Historico {

    public String emitir() {
        return "Histórico de Graduação";
    }
}
