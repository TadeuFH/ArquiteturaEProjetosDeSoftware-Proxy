package padroescriacao.abstractfactoryex1;

public class DisciplinaEnsinoMedio implements Disciplina{

    public String emitir() {
        return "Disciplina Ensino Medio";
    }
}
